/*1 уровень сложности: 1 Создайте Package (ПКМ на папке src -> New -> Package).
1.1 В созданном пакете создайте класс с минимум 3мя полями для одного из объектов реального мира (студент, батарейка, автомобиль…).
 Одно из полей сделайте публичным, второе – без модификатора доступа, остальные – приватными.
 Создайте объект этого класса в программе и попробуйте установить значения для полей. Какие поля возможно установить?
1.2 Создайте второй класс в том же пакете, в котором будет создаваться первый класс (например, класс Университет для класса
Студент или класс Завод для класса автомобиль). Внутри класса определите метод, который создаёт объект первого класса
 и присвойте ему те поля, которые возможно. Какие поля возможно задать?
1.3 Напишите минимум 2 конструктора для класса 1.
1.4 Реализуйте геттеры и сеттеры для приватных полей класса 1.
1.5 Создайте другие методы для класса (по желанию).
1.6 Добавьте клонирующий конструктор к классу 1. В программе склонируйте созданный ранее объект. Проверьте с помощью ==, что объекты имеют разные ссылки в памяти.
1.7 У клона измените одно из полей. Проверьте, что то же поле исходного объекта не изменилось.
*/
package electricbattery;

public class Battery {
    public String type;
    long idItem;
    private double voltage;
    private String produce;
    private boolean isRechargeable = true;

    public Battery() {

    }

    public Battery(double voltage) {
        this.voltage = voltage;

    }

    public Battery(String type) {
        this.type = type;
    }


    public Battery(String type, long idItem) {
        this(type);
        this.idItem = idItem;

    }


    public Battery(String type, long idItem, double voltage, String produce, boolean isRechargeable) {
        this(type, idItem);
        this.voltage = voltage;
        this.produce = produce;
        this.isRechargeable = isRechargeable;

    }

    public Battery(Battery original){
        this(original.type, original.idItem, original.voltage, original.produce, original.isRechargeable);

    }

    public String getType() {
        return type;

    }

    public void setType(String type) {
        if (type.isEmpty()) {
            throw new IllegalArgumentException("Type can't be empty");
        }
        this.type = type;
    }

    public long getIdItem() {
        return this.idItem;
    }

    public void setIdItem(long idItem) {
        if (idItem < 0) {
            throw new IllegalArgumentException("Number of item can't be negative.");
        }
    }

    public double getVoltage() {
        return this.voltage;
    }

    public void setVoltage(double voltage) {
        if (voltage == 0) {
            throw new IllegalArgumentException("Battery is running over!");
        }
        this.voltage = voltage;
    }

    public String getProduce() {
        return this.produce;
    }

    public void setProduce(String produce) {
        if (produce.isEmpty()) {
            throw new IllegalArgumentException("Manufacture must be indicated.");
        }
        this.produce = produce;

    }

    public boolean getIsRechargeable() {
        return isRechargeable;
    }

    public void setIsRechargeble(boolean isRechargeable) {
        if (!isRechargeable) {
            this.isRechargeable = false;
        }
    }

    public void readNote() {
        System.out.println("Please don't give battery for children under 5 years!");
    }
}
