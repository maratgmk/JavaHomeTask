package electricbattery;

public class Manufacture {

    Battery battery = new Battery();


    public void create() {
        battery.type = "AA";  // возможно взять значение свойства "type" с модификатором доступа "public"
        battery.idItem = 24358292; // возможно взять значение свойства "idItem" с модификатором доступа "default"
        // т.е. без указания модификатора
        battery.setProduce("Manufacture");


        System.out.printf("Battery %s with ID number #%d and produce by %s had well done already", battery.type, battery.idItem, battery.getProduce());

    }
    public void checkVoltage(){
        battery.setIsRechargeble(true);
        battery.setVoltage(15.278);
        System.out.printf("Battery is %b rechargeable, voltage is checked and equals: %f volt", battery.getIsRechargeable(),battery.getVoltage());
    }


}
