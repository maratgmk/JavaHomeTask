import students.Gender;
import students.Rating;
import students.Student;
import students.University;

import java.time.LocalDate;

public class Main2 {
    public static void main(String[] args) {
        Student st1 = new Student();
        st1.name = "Bob"; // доступно только одно поле с модификатором доступа public
        System.out.println(st1.name);
        University method = new University();
        method.learn();
        st1.showEstimate();
        Student st2 = new Student("Lada","Clever", Gender.IT, Rating.EXCELLENT, LocalDate.of(1758,7,2));
        System.out.printf("My name and surname are %s %s, I'm %d years old, I study IT on %s level and my sex is %s.", st2.name, st2.getSurname(),
                LocalDate.now().getYear() - st2.getAge().getYear(), st2.getEstimate(), st2.getGender());
        Student st2cloned = new Student(st2);
        System.out.println();
        System.out.println(st2 == st2cloned);
        System.out.println(st2.getGender() == st2cloned.getGender());
        st2cloned.setGender(Gender.FEMALE);
        System.out.println(st2.getGender() == st2cloned.getGender());


    }
}
