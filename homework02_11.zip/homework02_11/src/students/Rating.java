package students;

public enum Rating {
    EXCELLENT,
    GOOD,
    POOR,
    REPEATER
}
