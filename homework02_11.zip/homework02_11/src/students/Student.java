package students;

import java.time.LocalDate;

public class Student {
    public String name;
    String surname;
    private LocalDate age;
    private Gender gender;
    private Rating estimate;

    public Student(){

    }
    public Student(Student original){
        this(original.name, original.surname, original.gender,original.estimate, original.age);
    }

    public Student(String name, String surname){
        this.name = name;
        this.surname = surname;
    }
    public Student(Gender gender, Rating estimate){
        this.gender = gender;
        this.estimate = estimate;

    }
    public Student(String name, String surname, Gender gender, Rating estimate, LocalDate age){
        this(gender, estimate);
        this.age = age;
        this.name = name;
        this.surname = surname;
    }
    public String getSurname(){
        return surname;
    }
    public void setSurname(String surname){
        if(surname==null || surname.isEmpty()){
            throw new IllegalArgumentException("Surname can't be empty");
        }
        this.surname = surname;
    }
    public Gender getGender(){
        return gender;
    }
    public void setGender(Gender gender){
        if(gender==null){
            throw new IllegalArgumentException("Genger must be filled");
        }
        this.gender = gender;
    }
    public LocalDate getAge(){
        return age;
    }
    public void setAge(LocalDate age){
        if (age == null){
            throw new IllegalArgumentException("Age must be indicated");
        }
        this.age = age;
    }
    public Rating getEstimate(){
        return estimate;
    }
    public void setEstimate(Rating estimate){
        if(estimate == null){
            throw new IllegalArgumentException("Rating of examination can't be empty");
        }
        this.estimate = estimate;
    }

    public void showEstimate(){
        System.out.println("  My success is shown in estimate property.");
    }




}
