package students;

public enum Gender {
    MALE,
    FEMALE,
    OTHER,
    UNKOWN,
    IT

}
