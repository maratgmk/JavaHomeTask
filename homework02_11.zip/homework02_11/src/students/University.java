package students;

public class University {
    public void learn(){
        Student st1 = new Student();
        st1.name = "Gans"; // можно вызвать поле с модификатором public
        st1.surname = "Grune"; // можно вызвать поле с без модификатора (default)
        System.out.printf("Студент %s %s сдал экзамен по Java на %d.",st1.name,st1.surname,4);


    }
}
