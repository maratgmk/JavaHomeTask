import electricbattery.Battery;
import electricbattery.Manufacture;

public class Main {

    public static void main(String[] args) {
        Battery bat1 = new Battery("AA", 6738);
        System.out.println(bat1); // Это адрес кучи?
        System.out.println(bat1.getType());
        System.out.println(bat1.getIdItem());
        bat1.setIsRechargeble(true);
        System.out.println(bat1.getIsRechargeable());
        bat1.setProduce("Energizer");
        System.out.println(bat1.getProduce());
        // возможно установить значение свойства type, так как модификатор public
        // файл Main находится вне package electricbattery, поэтому свойства с модификатором
        // private и default не доступны
        Manufacture work = new Manufacture();
        work.create();
        System.out.println();
        Battery bat2 = new Battery("B", 26754, 7.84, "Cosmos", false);
        System.out.println(bat2); // чей и куда адрес?
        System.out.println(bat2.getType());
        System.out.println(bat2.getIdItem());
        System.out.println(bat2.getVoltage());
        System.out.println(bat2.getProduce());
        System.out.println(bat2.getIsRechargeable());
        bat1.readNote();
        work.checkVoltage();
        Battery clon = new Battery(bat2);
        System.out.println(clon == bat2);
        System.out.println(clon);
        clon.setVoltage(24.467);
        System.out.println(clon.getVoltage() == bat2.getVoltage());
        System.out.println(bat2.getVoltage());
        System.out.println(clon.getVoltage());
        System.out.println(clon.equals(bat2));


    }


}