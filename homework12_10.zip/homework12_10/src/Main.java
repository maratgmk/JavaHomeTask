/*
Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
Числа могут быть, как целочисленные, так и дробные.

Например :
ввод : m=7, n=11
вывод: Число 11 ближе к 10.
 */

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double m = scanner.nextDouble();
        double n = scanner.nextDouble();
        double abc = Math.abs(m - 10);
        double bac = Math.abs(n - 10);
        if (abc < bac) {
            System.out.println("Ближайшее к десяти число: " + m);
        } else {
            System.out.println("Ближайшее к десяти число: " + n);

        }
        /*
        Разработайте программу, которая принимает на вход длины трех сторон треугольника
        и определяет его тип (равносторонний, равнобедренный или разносторонний).
         */
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();
        if (a == b && b == c) {
            System.out.println("Треугольник равносторонний");
        }

        if (a == b || b == c || a == c) {
            System.out.println("Треугольник равнобедренный");
        }
            System.out.println("Треугольник разносторонний");
        }

    }


