/*
Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
Программа генерирует два целых однозначных числа. Программа задаёт вопрос: результат умножения первого числа на второе?
  Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
  Если пользователь ответил неправильно, то программа должна показать правильный ответ.


 */

import java.util.Random;
import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        int a = random.nextInt(10);
        int b = random.nextInt(10);
        System.out.println(a + "," + b);
        System.out.println("Сколько будет " + a + " умноженное на " + b + "?");
        int c = scanner.nextInt();
        System.out.println("Я думаю будет:  " + c);
        if (c == a * b) {
            System.out.println("Ответ верный");
        } else {
            System.out.println("Не правильно! Правильный ответ " + a * b);
        }
        /*
        2 Создайте программу для оценки студентов на основе их баллов. Пользователь вводит, сколько баллов набрал (от 0 до 100).
         Программа должна присваивать буквенные оценки (A, B, C, D, F) в зависимости от полученных баллов:
         A за 80 баллов и более, B за 60-79 баллов, С за 40-59 баллов, D за 20-39 баллов, F в остальных случаях.
         */
        int point = scanner.nextInt();
        if (point >= 80) {
            System.out.println("A");
        }
        if (point >= 60 && point <= 79) {
            System.out.println("B");
        }
        if (point >= 40 && point <= 59) {
            System.out.println("C");
        }
        if (point >= 20 && point <= 39) {
            System.out.println("D");}
        if (point<20) {
            System.out.println("F");
        }
    }
}
