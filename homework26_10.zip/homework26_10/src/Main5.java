import java.util.Arrays;

public class Main5 {
    public static void main(String[] args) {
        /*Дан двумерный массив 10x10. Заполните его символами в порядке возрастания их кодов.
        Начать нужно с символа &. Все виды скобок – (), {}, [] нужно заменить на символ %.
         */
        char[][] symbols = new char[10][10];
        char current = '&';
        for (int i = 0; i < symbols.length; i++) {
            for (int j = 0; j < symbols[i].length; j++) {
                symbols[i][j] = current == '(' || current == ')' || current == '[' || current == ']' || current == '{' || current == '}' ?
                        '%' : current;
                current++;
            }
        }
        System.out.println(Arrays.deepToString(symbols));
        for (char[] c:symbols) {
            for (char s:c) {
                System.out.print(s+" ");
            }
            System.out.println();
        }
    }

    }

