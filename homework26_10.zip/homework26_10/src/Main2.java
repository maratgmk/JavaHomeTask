/*1 Создайте массив из 8 элементов. В массиве должны храниться даты (класс LocalDate).
Чтобы создать элемент LocalDate, используйте метод LocalDate.of(год, месяц, день), где год, месяц и день – целые числа.
Выведите массив в консоль.
2 Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в консоль.
Сортировку можно выполнить по любому из изученных алгоритмов.*/
import java.time.LocalDate;
import java.util.Arrays;

public class Main2 {
    public static void main(String[] args) {
        LocalDate[] dates = {
                LocalDate.of(1789, 7, 14),
                LocalDate.of(1534, 12, 7),
                LocalDate.of(1918, 2, 23),
                LocalDate.of(1968, 4, 12),
                LocalDate.of(2000, 1, 1),
                LocalDate.of(2023, 10, 29),
                LocalDate.of(1989, 11, 11),
                LocalDate.of(1957, 5, 22),
        };

        System.out.println(Arrays.toString(dates));


        int[] years = {dates[0].getYear(), dates[1].getYear(), dates[2].getYear(), dates[3].getYear(), dates[4].getYear(), dates[5].getYear(), dates[6].getYear(), dates[7].getYear()};
        System.out.println(Arrays.toString(years));
        insertionSort(years);
        System.out.println(Arrays.toString(years));

        int[] days = {dates[0].getDayOfMonth(), dates[1].getDayOfMonth(), dates[2].getDayOfMonth(), dates[3].getDayOfMonth(), dates[4].getDayOfMonth(),
                dates[5].getDayOfMonth(), dates[6].getDayOfMonth(), dates[7].getDayOfMonth() };
        System.out.println(Arrays.toString(days));
        insertionSort(days);
        System.out.println(Arrays.toString(days));


    }

    private static void insertionSort(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > arr[i - 1]) continue;
            for (int j = i; j > 0; j--) {
                if (arr[j] > arr[j - 1]) break;
                swap(arr, j - 1, j);
            }
        }

    }

    private static void swap(int[] arr, int index1, int index2) {
        int temp = arr[index2];
        arr[index2] = arr[index1];
        arr[index1] = temp;
    }


}
