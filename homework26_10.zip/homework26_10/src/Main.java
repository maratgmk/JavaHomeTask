/*
Создайте двумерный массив и заполните его заглавными буквами русского алфавита. Буква Ё должна быть на своём месте.
 */

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        char[][] alf = new char[6][6];
          char letter = 'А';


        for (int i = 0; i < alf.length; i++) {
            for (int j = 0; j < alf[i].length; j++) {
                alf[i][j] = letter;
                letter++;
                if (letter > 'Я') break;
                if (letter == 'Ж') {
                    if (j == alf[i].length - 1) {
                        i++;
                        j = 0;
                    } else {
                        j++;
                    }
                    alf[i][j] = 'Ё';
                }


            }

        }
        System.out.println(Arrays.deepToString(alf));


      }
}
