/*Двумерные массивы
Дан двумерный массив 10x10. Заполните его символами в порядке возрастания их кодов. Начать нужно с символа &.
Все виды скобок – (), {}, [] нужно заменить на символ %. */


import java.util.Arrays;

public class Main4 {

    public static void main(String[] args) {
        char[][] symbols = new char[10][10];
        char sign = '&';
        for (int i = 0; i < symbols.length; i++) {
            for (int j = 0; j < symbols[i].length; j++) {
                symbols[i][j] = sign;
                if ( sign == '(' || sign == ')' || sign == '{' || sign == '}' || sign == '[' || sign == ']') {

                    symbols[i][j] = '%';
                } else {
                    symbols[i][j] = sign;
                }
                sign++;
            }
        }
        System.out.println(Arrays.deepToString(symbols));
    }
}






