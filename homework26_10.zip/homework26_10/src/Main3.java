/*Сортировки
1 Дан массив строк. Напишите сортировку, которая отсортирует строки по длине. Для получения строки используйте метод length().
2 Дан массив символов. В массиве могут быть только заглавные буквы английского алфавита. Символы могут повторяться.
 Напишите сортировку, которая отсортирует символы по алфавиту.
 */

import java.util.Arrays;

public class Main3 {
    public static void main(String[] args) {
        String[] arr = {"asdff", "qeqqeqeteqw", "sdf", "qetertqetert", "sf", "wrqwrqr"};
        int[] arrr = {"asdff".length(), "qeqqeqeteqw".length(), "sdf".length(), "qetertqetert".length(), "sf".length(), "wrqwrqr".length()};
        System.out.println(Arrays.toString(arr));
        System.out.println(Arrays.toString(arrr));
        insertionSort(arrr);
        System.out.println(Arrays.toString(arrr));


    }


    private static void insertionSort(int[] ar) {
        for (int i = 1; i < ar.length; i++) {
            if(ar[i] > ar[i-1])continue;
            for (int j = i; j > 0 ; j--) {
                if(ar[j] > ar[j-1])break;
                swap( ar, j-1, j);
            }
        }
    }
    private static void swap( int[] ar, int index1, int index2){
       int temp = ar[index2];
        ar[index2] = ar[index1];
        ar[index1] = temp;
   }


}













