package consultation;

public enum TimeOfDay {
    MORNING,
    MIDDAY,
    EVENING,
    NIGHT

}
