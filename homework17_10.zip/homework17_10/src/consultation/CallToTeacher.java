package consultation;
/*
Программа «Созвон с преподавателем». Создайте перечисление времени суток (утро, день, вечер, ночь).
Пользователь вводит, когда он готов созвониться с преподавателем, чтобы задать вопросы по домашнему заданию.
Компьютер случайным образом выбирает, в какое время свободен преподаватель. Если время суток совпало,
то программа должна вывести «Созвон состоялся». Если не совпало, то программа выводит «не сегодня».
 */

import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class CallToTeacher {
    public static void main(String[] args) {
        System.out.println("Я готов созвонится  " + Arrays.toString(TimeOfDay.values()));
        String myStr = new Scanner(System.in).nextLine();
        TimeOfDay myCall = TimeOfDay.valueOf(myStr.toUpperCase(Locale.ROOT));
        System.out.println(myCall);

        Random random = ThreadLocalRandom.current();
        int numOfTeacher = random.nextInt(5);
        TimeOfDay timeOfTeacher = switch (numOfTeacher){
            case 1-> TimeOfDay.MORNING;
            case 2-> TimeOfDay.MIDDAY;
            case 3-> TimeOfDay.EVENING;
            case 4-> TimeOfDay.NIGHT;
            default -> throw new RuntimeException("Звонок не возможен " + numOfTeacher);
        };
        System.out.println(timeOfTeacher);

        if(myCall==timeOfTeacher){
            System.out.println("Созвон состоялся!");
        }else {
            System.out.println("Не сегодня...");
        }


    }
}
