package wedding;

public enum WeddingCelebrate {
    GAUZE,
    PAPER,
    SKIN,
    FLAX,
    WOOD,
    IRON,
    COPPER,
    SHEET_PLATE,
    CAMOMILE,
    TIN,
    STEAL,
    NICKEL,
    LILLY_OF_THE_VALLEY,
    AGATE,
    CRYSTAL




}
