package wedding;

import java.util.Arrays;
import java.util.Scanner;

public class Celebration {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            int numOfYear  = scanner.nextInt();
           System.out.println("You marriage always: " + numOfYear + " years");

          WeddingCelebrate nextWedding = switch (++numOfYear) {
                case 1 -> WeddingCelebrate.GAUZE;
                case 2 -> WeddingCelebrate.PAPER;  // почему нельзя здесь использовать метод nextWedding.name() ?
                case 3 -> WeddingCelebrate.SKIN ;
                case 4 -> WeddingCelebrate.FLAX;
                case 5 -> WeddingCelebrate.WOOD;
                case 6 -> WeddingCelebrate.IRON;
                case 7 -> WeddingCelebrate.COPPER;
                case 8 -> WeddingCelebrate.SHEET_PLATE;
                case 9 -> WeddingCelebrate.CAMOMILE;
                case 10 -> WeddingCelebrate.TIN;
                case 11 -> WeddingCelebrate.STEAL;
                case 12 -> WeddingCelebrate.NICKEL;
                case 13 -> WeddingCelebrate.LILLY_OF_THE_VALLEY;
                case 14 -> WeddingCelebrate.AGATE;
                case 15 -> WeddingCelebrate.CRYSTAL;

                default -> throw new RuntimeException("Unexpected value: " + numOfYear);
            };

            System.out.println("Next Wedding will be: " + nextWedding);

           WeddingCelebrate wedding = WeddingCelebrate.GAUZE;
           System.out.println(wedding.name());
           System.out.println(wedding.ordinal());


            System.out.println("Какая ваша свадьба?  " + (Arrays.toString(WeddingCelebrate.values())));
            String userStr = new Scanner(System.in).nextLine(); // надо обязательно новый второй сканер?

            WeddingCelebrate userWedding = WeddingCelebrate.valueOf(userStr.toUpperCase());
            System.out.println(userWedding);

        }
    }



