package suefa;

import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Su_E_Fa {
    public static void main(String[] args) {


        System.out.println("My move " + Arrays.toString(StoneScissorsPaper.values()));
        String myStr = new Scanner(System.in).nextLine();
        StoneScissorsPaper myMove = StoneScissorsPaper.valueOf(myStr.toUpperCase(Locale.ROOT));
        System.out.println(myMove);

        Random random = ThreadLocalRandom.current();
        int numMove = random.nextInt(0,3);
        StoneScissorsPaper compMove = switch (numMove) {
            case 1 -> StoneScissorsPaper.STONE;
            case 2 -> StoneScissorsPaper.SCISSORS;
            case 3 -> StoneScissorsPaper.PAPER;
            default -> StoneScissorsPaper.PAPER;
        };
        System.out.println(compMove);

        if(myMove==compMove){
            System.out.println("Draw game!");
        }
        if (myMove==StoneScissorsPaper.STONE&&compMove==StoneScissorsPaper.PAPER){
            System.out.println("I lost...");}
        if (myMove==StoneScissorsPaper.STONE&&compMove==StoneScissorsPaper.SCISSORS){
            System.out.println("I won!");}
        if (myMove==StoneScissorsPaper.SCISSORS&&compMove==StoneScissorsPaper.PAPER){
            System.out.println("I won!");}
        if(myMove==StoneScissorsPaper.SCISSORS&&compMove==StoneScissorsPaper.STONE){
            System.out.println("I lost..");}
        if (myMove==StoneScissorsPaper.PAPER&&compMove==StoneScissorsPaper.STONE){
            System.out.println("I won!");}
        if (myMove==StoneScissorsPaper.PAPER&&compMove==StoneScissorsPaper.SCISSORS){
            System.out.println("I lost...");
        }










    }
}
