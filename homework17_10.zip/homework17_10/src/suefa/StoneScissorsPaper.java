package suefa;

public enum StoneScissorsPaper {
    STONE,
    SCISSORS,
    PAPER
}
