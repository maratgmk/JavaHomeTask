/*Задание 3. Задание из собеседования Яндекс:
дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой.
Если буква одна, то цифра не ставится.
*/
/*Дана строка вида A4B3C3D2EG. Напишите метод, который развернёт строку до вида AAAABBBCCCDDEG */
import java.util.Arrays;
public class Main2 {
    public static void main(String[] args) {
        String str = "A4B3C3D2EG";
        char[] symbols = str.toCharArray();
        System.out.println(Arrays.toString(symbols));
        System.out.println(getNewString(str));
        String str2 = "AAAABBBCCCDDEG";
        System.out.println(getNewString2(str2));
    }
    private static String getNewString(String str){
        char[] arr = str.toCharArray();
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < arr.length; i++) {
            if (Character.isDigit(arr[i])){
                String forLetter = String.valueOf(arr[i-1]).repeat(Character.getNumericValue(arr[i]));
                sb.append(forLetter);
            }else {
                if(Character.isLetter(arr[i-1])){
                    sb.append(arr[i-1]);
                }
            }
        }
        return sb.toString();
    }
    private static String getNewString2(String str){
        char[] arr = str.toCharArray();
        StringBuilder sb = new StringBuilder();
        int count = 1;
        char prevLetter = arr[0];
        for (int i = 1; i < arr.length; i++) {
            char currentLetter = arr[i];
            if (prevLetter==currentLetter){
                count++;
            }else {
                sb.append(prevLetter);
                prevLetter = currentLetter;
                sb.append(count == 1 ? "" : count);
                count = 1;
            }
        }
        return sb.toString();
    }


}
