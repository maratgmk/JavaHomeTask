import java.util.Arrays;
import java.util.Scanner;

/*
1 Пользователь вводит название. Программа должна создать аббревиатуру для названия. Например,
ввод: Life’s good; вывод: LG
ввод: Kentucky Fried Chicken; вывод: KFC
ввод: New York; вывод: NY

*/
public class Main3 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        String str = scn.nextLine();
        System.out.println("Input: " + str);
        String[] lines = str.split(" ");
        System.out.println(Arrays.toString(lines));
        System.out.println(Arrays.toString(str.split(" ")));
       StringBuilder output = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            output.append(lines[i].toUpperCase().charAt(0));

        }


    }
}
