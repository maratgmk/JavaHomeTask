/*Напишите программу, моделирующую работу табло при ожидании лифта.
В здании 35 этажей. Лифт находится на произвольном этаже в диапазоне от 0 до 35 (выбирается
случайно). Пользователь нажимает кнопку вызова лифта (вводит на каком этаже он находится).
После этого лифт начинает движение. Пользователь может видеть, как лифт движется по этажам
(программа должна выводить каждый этаж лифта, когда лифт движется)*/

import java.util.Random;
import java.util.Scanner;

public class LiftAgain {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        int lift = random.nextInt(0,36);
        System.out.println("Лифт на " + lift + " этаже");
        System.out.println("На каком вы этаже?");
        int userlift = scanner.nextInt();
        System.out.println("Я на " + userlift + " этаже");
        int max = Math.max(lift,userlift);
        int min = Math.min(lift,userlift);
        for (int i = min; i <= max; i++) {
            System.out.println(i);
        }

        }

}
