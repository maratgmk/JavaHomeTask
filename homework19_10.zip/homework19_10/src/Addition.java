import java.util.Scanner;

/*Используйте for для вычисления суммы.
Используйте do-while для организации повторения программы.

Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем. Программу повторять, пока пользователь не введёт «quit».
*/
public class Addition {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println("Input any two numbers");
            int number1 = scanner.nextInt();
            int number2 = scanner.nextInt();
            int max = Math.max(number1, number2);
            int min = Math.min(number1, number2);
            int sum = 0;
            for (int i = min; i <= max; i++) {
                if (!(i % 2 == 0)) {
                    sum = sum + i;

                }


            }
            System.out.println(sum);
            System.out.println("Continue to add?");
        }
            while (!"Quit".equalsIgnoreCase(new Scanner(System.in).nextLine()));



    }
}