package dayofweek;

import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

/*Используйте foreach.
Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
Программа должна вывести все дни недели, кроме данного.*/
public class ForEach {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        for (DayOfWeek day : DayOfWeek.values()) {



            System.out.println(day.name() + "," + day.ordinal());

            System.out.println("Input day of week " + Arrays.toString(DayOfWeek.values()));
            String userStr = scanner.nextLine();
            DayOfWeek userDay = DayOfWeek.valueOf(userStr.toUpperCase(Locale.ROOT));
            System.out.println(userDay);




        }
    }
}

