package birthday;/*Напиши программу, которая моделирует ситуацию.
Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
Каждый друг случайным образом может подарить тебе одну купюру номиналом
50, 100, 200 или 500 долларов. Твоя цель - новенький игровой компьютер,
который стоит 10 000 долларов.
Как только друзья подарят тебе нужную сумму (или даже чуть больше),
 останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!*/


import birthday.BankNote;

import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class ReceiveMoney {
    public static void main(String[] args) {
        Random random = new Random();
        // System.out.println("Cast friend choice " + Arrays.toString(BankNote.values()));
        //String strFriend = random.toString();
        // BankNote choice = BankNote.valueOf(strFriend.toUpperCase(Locale.ROOT));
        int sum = 0;
        while (sum <= 10000) {

            int castFriend = random.nextInt(1, 5);
            System.out.println(castFriend);
            BankNote note = switch (castFriend) {
                case 1 -> BankNote.FIFTY;
                case 2 -> BankNote.ONE_HUNDRED;
                case 3 -> BankNote.TWO_HUNDRED;
                case 4 -> BankNote.FIVE_HUNDRED;
                default -> throw new RuntimeException("No money");
            };

            System.out.println(note);
            int money = switch (note) {
                case FIFTY -> 50;
                case ONE_HUNDRED -> 100;
                case TWO_HUNDRED -> 200;
                case FIVE_HUNDRED -> 500;
            };

            sum = sum + money;
            System.out.println(sum);
        }
    }
}
