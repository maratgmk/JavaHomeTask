package birthday;

public enum BankNote {
    FIFTY,
    ONE_HUNDRED,
    TWO_HUNDRED,
    FIVE_HUNDRED
}
