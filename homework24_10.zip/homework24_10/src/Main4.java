import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*
Массивы
1. Создайте массив из 5 случайных целых чисел из интервала [-10;10]. Отсортируйте массив.
 Все элементы с индексом, кратным 3, замените на число 3, а все элементы с индексом, кратным 5,
 замените на число 5.
2 Создайте массив из 5 строк. Каждая строка – это предложение, оканчивающееся одним
 из знаков препинания:".", или "!", или "?". Напишите программу, которая выведет в консоль количество знаков препинания каждого типа.
  Для получения последнего символа строки используйте методы charAt() и length().*/
public class Main4 {
    public static void main(String[] args) {
        Random random = new Random();
        int[] arr = new int[5];
        for (int i = 0; i < 5; i++) {
            arr[i] = random.nextInt(-10,11);

        }
        System.out.println(Arrays.toString(arr));
        int[] arrClon = arr.clone();
        System.out.println(Arrays.toString(arrClon));
        Arrays.sort(arrClon);
        System.out.println(Arrays.toString(arrClon));
        for (int i = 0; i < 5; i++) {
            if(arrClon[i]%3==0){
                arrClon[i] = 3;

            }if(arrClon[i]%5==0){
                arrClon[i] = 5;
            }
        }
        System.out.println(Arrays.toString(arrClon));


        String[] sentence = new String[]{"Good morning!","Is it true?","Would you like a coffee?","It is cold today.","What a wonderful day!"};
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;

        for (int i = 0; i < sentence.length; i++) {
           System.out.println(sentence[i].charAt(sentence[i].length() - 1));
            if(sentence[i].charAt(sentence[i].length()-1)=='!'){
                count1 = count1 + 1;
            } else if (sentence[i].charAt(sentence[i].length()-1)=='.') {
                count2 = count2 + 1;
            }else {
                count3 = count3 + 1;

            }

        }System.out.println("Количество знаков '!' равно: " + count1);
        System.out.println("Количество знаков '.' равно: " +count2);
        System.out.println("Количество знаков '?' равно: " +count3);


    }
}
