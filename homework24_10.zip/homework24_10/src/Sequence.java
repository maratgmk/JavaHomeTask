import java.util.Scanner;

/*2 Используя рекурсию, написать метод для вычисления суммы n элементов ряда 1/n.
 Например, n=5, тогда 1/1 + 1/2 + 1/3 + 1/4 + 1/5 = 2,28333*/
public class Sequence {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n =  scanner.nextInt();
        System.out.println("Введённое число n равно: " + n);
        System.out.println("Сумма " + n + " элементов ряда 1/n равна: "+ seqSum(n));


    }

    private static double seqSum(int n) {
        double result = 0;
        if(n<=0){
            return result;
        }
         result = (double)1/n;
         result = (double)(result+ seqSum((n-1)));
        return result;

    }
}
