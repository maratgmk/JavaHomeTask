/*  №1.
1. Создайте массив из 8 случайных целых чисел из интервала [1;50]
2. Выведите массив в консоль в строку.
3. Замените каждый элемент с нечетным индексом на ноль.
4. Снова выведете массив в консоль в отдельной строке.
5. Отсортируйте массив по возрастанию.
6. Снова выведете массив в консоль в отдельной строке.
№2.
1. Создайте массив из 5 строк. Используя метод length() строк,
найдите строку с наибольшей длиной и строк с наименьшей
длиной.
2. Выведите массив и полученный строки в консоль
  */


import java.util.Arrays;
import java.util.Random;

import static java.lang.Math.random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        int a = random.nextInt(1,51);
        int b = random.nextInt(1,51);
        int c = random.nextInt(1,51);
        int d = random.nextInt(1,51);
        int f = random.nextInt(1,51);
        int g = random.nextInt(1,51);
        int e = random.nextInt(1,51);
        int h = random.nextInt(1,51);

        int[] numbers = {a,b,c,d,e,f,g,h,};
        System.out.println("{" + numbers[0] + "," + numbers[1] + "," + numbers[2] + "," +  numbers[3] +"," + numbers[4] + "," + numbers[5] + "," +numbers[6] + "," + numbers[7] +"}" );
        System.out.println(Arrays.toString(numbers));
        int[] dublicate = numbers.clone();
        Arrays.sort(dublicate);
        System.out.println(Arrays.toString(dublicate));
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        int[] num = new int[8];
        System.out.println(Arrays.toString(num));
        for (int i = 0; i < num.length; i++) {
            num[i] = random.nextInt(1,51);
        }
        System.out.println(Arrays.toString(num));
        System.out.println(Arrays.toString(getEven(num)));
        int[] cloned = num.clone();
        System.out.println(num.toString());
        System.out.println(Arrays.toString(cloned));
        System.out.println(num.equals(cloned));
        System.out.println(Arrays.equals(num,cloned));
        Arrays.sort(cloned);
        System.out.println(Arrays.toString(cloned));
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        String[] lines = {"Python","Owl","Delphin","Squirrel","Rhino"};
        int[] lengthLines = {lines[0].length(),lines[1].length(),lines[2].length(),lines[3].length(),lines[4].length()};
        System.out.println(Arrays.toString(lines));
        System.out.println(Arrays.toString(lengthLines));
        //int[] lengthLines = new int[lines.length];
        lengthLines = getInt(lines);
        System.out.println(Arrays.toString(lengthLines));
        int[] clonedLines = lengthLines.clone();
        Arrays.sort(clonedLines);
        System.out.println(Arrays.toString(clonedLines));
        System.out.println(clonedLines[0]);
        System.out.println(clonedLines[4]);
        System.out.println(lines[1]);
        System.out.println(lines[3]);





    }
    private static int[] getEven(int[] num){
        for (int i = 0; i < num.length; i++) {
            if(!(i%2==0)){
                num[i]=0;
            }
        }return num;
    }
    private static int[] getInt(String[] lines) {

          int[] intLines = new int[lines.length];
        for (int i = 0; i < lines.length; i++) {

            intLines[i] = lines[i].length();
        }
        return intLines;
    }
    
    

  }