import java.util.Scanner;

/* Задание 1.
Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х
чисел. В методе умножения 3-х чисел используйте вызов метода для
2-х чисел. В методе умножения 4-х чисел – вызов метода для 3-х
чисел.*/

public class Main2 {
    public static void main(String[] args) {
        System.out.println(mult(23,45));
        System.out.println(mult(22, 56, 89));
        System.out.println(mult(23, 11, 34, 39));
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.print("Дано число:  " + n);
        String startStr = "n!";
        String result = String.valueOf(addSame(startStr, n));


    }



    public static int mult(int num1,int num2){
        int result = num1*num1;
        return result;
            }
    public static int mult(int num1,int num2, int num3){
        int result = mult(num1,num2)*num3;
        return result;
    }
    public static int mult(int num1,int num2,int num3,int num4){
        int result = mult(num1,num2,num3)*num4;
        return result;
    }
    public static int addSame(String str,  int n){
        System.out.println(str);
        if (str.length()>n){
            return n;
        }return addSame(str+"*"+str,n);
    }

}
