/*Задания для продлёнки
Методы
1. Сделайте перегруженные методы для нахождения среднего числа из 2-х, 3-х и 4-х чисел.
*/
public class Main3 {
    public static void main(String[] args) {
        System.out.println(getAverage(39, 82));
        System.out.println(getAverage(12, 59, 87));
        System.out.println(getAverage(18, 29, 47, 63));

    }

    private static int getAverage(int num1, int num2){
        int result = (num1+num2)/2;
        return result;
    }

    private static int getAverage(int num1, int num2, int num3){
        int result = (getAverage(num1,num2) + num3)/3;
        return result;
    }
    private static int getAverage(int num1, int num2, int num3, int num4){
        int result = (getAverage(num1,num2,num3) + num4)/4;
        return result;
    }
}
