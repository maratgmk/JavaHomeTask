import java.util.Scanner;

/*Задание 2.
Используя рекурсию, написать метод вычисления факториала числа n
(n!), вводимого с клавиатуры.*/
public class Factorial {
    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.println("Введённое число: " + n);
        System.out.println("Факториал числа " + n + " равен: " + n + "!=" + factorial(n));

    }

    private static int   factorial(int n){
        int result = 1;
        if(n==1 || n==0){
            return result;
        }
        result = n * factorial((n-1));
        return result;

    }
}

// Решение взято с сайта "JAVARUSH"


