/*
4 Пользователь вводит целое число. Напишите программу, которая делит это число на 2 и выводит результат.
 Остаток деления можно отбросить. Операторы деления /, умножения * и остатка от деления % применять нельзя.
         */

/*
4 Ввести целое число n. Вывести 2 в степени n, используя битовые операции.
 */

import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        System.out.println(a>>1);

        System.out.println(2<<a);


    }
}
