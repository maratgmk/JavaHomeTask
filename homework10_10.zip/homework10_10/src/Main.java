/*
        1 уровень сложности: 1 Дана длина в метрах. Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
         Выведите начальное и конвертированные значения на экран.


         1 Создайте конвертер температур градусов Цельсия в градусы Кельвина и градусы Фаренгейта.
 */


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        double k1 = 1000;
        double k2 = 1852;
        double k3 = 3.28;
        double k4 = 1.4061;
        Scanner scanner = new Scanner(System.in);

        System.out.println("Input distance in meters: ");
        double distance = scanner.nextDouble();
        double km = distance/k1;
        double miles = distance/k2;
        double foots = distance*k3;
        double arsh = distance*k4;


        System.out.println("Distance in kilometers is: " + km + " (km); Distance in miles is: " + miles + " (miles);  Distance in foots is: " + foots + " (foots);   Distance in arshines is: " + arsh + " (arshines).");

        System.out.println("Input Temperature in Celcius degrees:  ");
        double tc = scanner.nextDouble();
        System.out.println("Temperature in Fahrenheit is:  " + (tc*9/5 + 32) + " F");
        System.out.println("Temperature in Kelvin is: " + (tc + 273.15) + " K");

    }
}