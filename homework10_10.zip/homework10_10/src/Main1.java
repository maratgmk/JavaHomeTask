/*
2 Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
 Выведите сумму сдачи в виде “X рублей и Y копеек”.
 */


/*
2 Пользователь вводит, за какое количество минут он пробежал марафон (42 км).
Программа должна вывести на сколько часов и минут пользователь медленнее, чем чемпион мира, пробежавший марафон за 2 часа 1 минуту.
Выведите результат в виде: “Вы медленнее на X часов и Y минут”.


 */
import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Необходимо количество   x:  "  );
        int x = scanner.nextInt();
        System.out.println("x = "+x);
        System.out.println("Необходимо количество  y:  ");
        int y = scanner.nextInt();
        System.out.println("y = "+y);

        System.out.println("Стоимость Вашей покупки составила " + x + " лир и " + y +  " сантимов");

        System.out.println("Внесли в кассу z лир  ");
        int z = scanner.nextInt();
        System.out.println("z = "+z);
        System.out.println("Внесли в кассу w сантимов  ");
        int w = scanner.nextInt();
        System.out.println("w = "+w);
        System.out.println("Вы дали " +z+ " лир " +w+ " сантимов");

        System.out.println("Ваша сдача " + (z - x -1) + " лир " + (100 + w - y)+ " сантимов");

        System.out.println("===========================================================================================");

        System.out.println("Количество часов  a:  " );
        int a = scanner.nextInt();
        System.out.println("Таймер показал количество часов " +a);
        System.out.println("Количество минут b:  ");
        int b = scanner.nextInt();
        System.out.println("Таймер показал количество минут "+b);
        System.out.println("Вы пробежали дистанцию за "+a+" часа и "+b+" минут");
        System.out.println("Вы медленнее на "+(a - 2)+" часа и "+(b-1)+" минут");







    }
}
