import java.util.Random;

/*
3 Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather), то ребята пойдут в поход.
 Если туркружок закупит дождевики (hasBoughtRaincoats) к концу учебного года, то ребята пойдут в поход даже в плохую погоду.
 В поход ребят должен кто-то повести. Поведёт тренер Джим, если он освободится от сдачи тренерского экзамена (isJimFree),
  или тренер Кейт, если она вернётся из путешествия (hasKateComeBack). Вести детей может только один тренер.
  Если Джим и Кейт смогут вести детей вместе, то они обязательно поссорятся из-за этого и никто никуда не пойдёт.



  3 Вы решили создать приложение для управления автомобилями на вашей автопарковке. Для этого вам необходимо определить,
   сможет ли автомобиль выехать с парковки в определенные условия. Напишите логическое выражение, которое будет определять,
   сможет ли автомобиль выехать с парковки или нет.

Условия:
Дороги сейчас не заняты голубями (noPigeonsOnRoad).
Дороги чистые от снега (isRoadClear).
За рулём автомобиля сидит владелец (isOwner) или автомобиль вывозит эвакуатор (isEvacuator).
Во время эвакуации водитель не может сидеть за рулём.
Если за рулём владелец, то
Бензобак автомобиля не пуст (isNotEmpty).
Водитель старше 18 лет (isDriverOldEnough).
Определите начальные значения переменных так, чтобы автомобиль смог выехать с парковки.
 */

public class Main2 {
    public static void main(String[] args) {
        Random random = new Random();
        boolean isYearFinished = random.nextBoolean();
        System.out.println("isYearFinished: " +isYearFinished);
        boolean isGoodWeather = random.nextBoolean();
        System.out.println("isGoodWeather: "+isGoodWeather);
        boolean hasBoughtRaincoats = random.nextBoolean();
        System.out.println("hasBoughtRaincoats: " +hasBoughtRaincoats);
        boolean isJimFree = random.nextBoolean();
        System.out.println("isJimFree: " + isJimFree);
        boolean hasKateComeBack = random.nextBoolean();
        System.out.println("hasKateComeBack: " +hasKateComeBack);
        boolean isChildrenTrip = ((isYearFinished&&isGoodWeather)||(hasBoughtRaincoats&&isYearFinished))&&(isJimFree^hasKateComeBack);
        boolean isChildrenTrip2 = (isYearFinished&&isGoodWeather)&&(isJimFree^hasKateComeBack)||(hasBoughtRaincoats&&isYearFinished)&&(isJimFree^hasKateComeBack);
        System.out.println(isChildrenTrip);
        System.out.println(isChildrenTrip2);

        System.out.println("=====================================================================================================");

        boolean noPigeonsOnRoad = random.nextBoolean();
        System.out.println(noPigeonsOnRoad);
        boolean isRoadClear = random.nextBoolean();
        System.out.println(isRoadClear);
        boolean isOwner = random.nextBoolean();
        System.out.println(isOwner);
        boolean isEvacuator = random.nextBoolean();
        System.out.println(isEvacuator);
        boolean isNotEmpty = random.nextBoolean();
        System.out.println(isNotEmpty);
        boolean isDriverOldEnough = random.nextBoolean();
        System.out.println(isDriverOldEnough);
        boolean isCarOutPark = (noPigeonsOnRoad&&isRoadClear&&isOwner&&isDriverOldEnough&&isNotEmpty)^(isEvacuator&&noPigeonsOnRoad&&isRoadClear);

        System.out.println(isCarOutPark);




    }
}
